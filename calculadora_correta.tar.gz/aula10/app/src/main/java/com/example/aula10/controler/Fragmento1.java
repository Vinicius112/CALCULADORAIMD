package com.example.aula10.controler;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;


import androidx.fragment.app.Fragment;

import com.example.aula10.R;

public class Fragmento1 extends Fragment {

    private String novaString = "";

    public Fragmento1() {


    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Button bt08;



        View view = inflater.inflate(R.layout.fragment_fragmento1, container, false);



        Button bt1;
        bt1 = view.findViewById(R.id.btn1);


        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("1"));
            }
        });


        Button bt2;
        bt2 = view.findViewById(R.id.btn2);


        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("2"));
            }
        });

        Button bt3;
        bt3 = view.findViewById(R.id.btn3);


        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("3"));
            }
        });

        Button bt4;
        bt4 = view.findViewById(R.id.btn4);


        bt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("4"));
            }
        });

        Button bt5;
        bt5 = view.findViewById(R.id.btn5);


        bt5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("5"));
            }
        });

        Button bt6;
        bt6 = view.findViewById(R.id.btn6);


        bt6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("6"));
            }
        });

        Button bt7;
        bt7 = view.findViewById(R.id.btn7);


        bt7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("7"));
            }
        });

        Button bt8;
        bt8 = view.findViewById(R.id.btn8);


        bt8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("8"));
            }
        });

        Button bt9;
        bt9 = view.findViewById(R.id.btn9);


        bt9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("9"));
            }
        });



        Button bt0;
        bt0 = view.findViewById(R.id.btn0);


        bt0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("0"));            }
        });




        //Operações:

        Button btAd;
        btAd = view.findViewById(R.id.btnAd);


        btAd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("+"));
            }
        });


        Button btSu;
        btSu = view.findViewById(R.id.btnSu);


        btSu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("-"));
            }
        });



        Button btMu;
        btMu = view.findViewById(R.id.btnMu);


        btMu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("*"));
            }
        });


        Button btDi;
        btDi = view.findViewById(R.id.btnDi);


        btDi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(inserirCaractere("/"));
            }
        });



        Button btDe;
        btDe = view.findViewById(R.id.btnDe);


        btDe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(remover());
            }
        });

        Button btIg;
        btIg = view.findViewById(R.id.btnIg);

        btIg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                novaString = sinalNoFim(novaString);
                // Ação a ser executada quando o botão for pressionado
                TextView textView = (TextView) getView().findViewById(R.id.result);
                textView.setText(resultado(novaString));

                textView = (TextView) getView().findViewById(R.id.entrada);
                textView.setText(novaString);
            }
        });



        return view;




    }



    String inserirCaractere(String opera){
        if(novaString.length() == 0 &&
          (opera == "+" || opera == "-" || opera == "*" || opera == "/")
            ) {
             return this.novaString;
        }

            this.novaString = this.novaString + opera;
            return this.novaString;


    }

    String remover(){
        if(this.novaString.length() > 0) {
            this.novaString = this.novaString.substring(0, this.novaString.length() - 1);
        }
        return this.novaString;
    }

    String resultado(String resultado){

        if(divPorZero(this.novaString)){
            this.novaString = "";
            return "DIV 0";
        }


        double res;
        Expression expression = new ExpressionBuilder(resultado).build();
        res = expression.evaluate();
        resultado =  String.format("%.1f", res); // Formata com 2 casas decimais
        this.novaString = "";
        return resultado;

    }

    boolean divPorZero(String expressao){
      for(int i = 0; i < expressao.length(); i++){
          if(i != expressao.length()-1
                  && expressao.charAt(i) == '/'
                  && expressao.charAt(i+1) == '0'){
              return true;
          }
      }
      return false;
     }


    String sinalNoFim(String expressao){
        if(expressao.charAt(expressao.length()-1) == '-'
                ||expressao.charAt(expressao.length()-1) == '+'
                ||expressao.charAt(expressao.length()-1) == '*'
                ||expressao.charAt(expressao.length()-1) == '/'){
            return expressao.substring(0, expressao.length() - 1);
        }

        return expressao;
    }


}