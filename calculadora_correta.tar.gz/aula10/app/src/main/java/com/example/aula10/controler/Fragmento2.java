package com.example.aula10.controler;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.aula10.R;

public class Fragmento2 extends Fragment {

    private String note1 = "";
    private String note2 = "";
    private String note3 = "";


    public Fragmento2() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fragmento2, container, false);
        Button btMe;
        btMe = view.findViewById(R.id.btnMe);


        btMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                // Ação a ser executada quando o botão for pressionado
                EditText n1 = getView().findViewById(R.id.nota1);
                note1 = n1.getText().toString();

                EditText n2 = getView().findViewById(R.id.nota2);
                note2 = n2.getText().toString();

                EditText n3 = getView().findViewById(R.id.nota3);
                note3 = n3.getText().toString();

                TextView textView;


                String note1Clone = note1;
                String note2Clone = note2;
                String note3Clone = note3;

                notaFaltante();

                if (note1Clone.isEmpty()) {
                    textView = (TextView) getView().findViewById(R.id.nota1);
                    textView.setText(note1);
                }
                if (note2Clone.isEmpty()) {
                    textView = (TextView) getView().findViewById(R.id.nota2);
                    textView.setText(note2);
                }
                if (note3Clone.isEmpty()) {
                    textView = (TextView) getView().findViewById(R.id.nota3);
                    textView.setText(note3);
                }

                if(!isNotNumeric(note1) && !isNotNumeric(note2) && !isNotNumeric(note3)){
                textView = (TextView) getView().findViewById(R.id.resultMean);


                textView.setText(calcularmedia(note1, note2, note3));


                textView = (TextView) getView().findViewById(R.id.situacaoR);
                textView.setText(
                        situacao(
                                Double.parseDouble(
                                        calcularmedia(note1, note2, note3)
                                                .replace(",", ".")
                                )
                        )
                );


            }





            }

        });


        return view;
    }



    public void notaFaltante() {
        Double not1, not2, not3;
        Double not1Nota, not2Nota, not3Nota;

        if (note1.isEmpty() && !note2.isEmpty() && !note3.isEmpty() ) {
            not2 = Double.parseDouble(note2);
            not3 = Double.parseDouble(note3);
            not1 = 21 - (not2 + not3);
            not1Nota = 15 - (not2 + not3);
            this.note1 = "Apv: " + Double.toString(not1)
                    + "| ApvNota: " + Double.toString(not1Nota);

        } else if (!note1.isEmpty() && note2.isEmpty() && !note3.isEmpty()) {
            not1 = Double.parseDouble(note1);
            not3 = Double.parseDouble(note3);
            not2 = 21 - (not1 + not3);
            not2Nota = 15 - (not1 + not3);
            this.note2 = "Apv: " + Double.toString(not2)
                    + "| ApvNota: " + Double.toString(not2Nota);


            this.note2 = Double.toString(not2);
        } else if (!note1.isEmpty() && !note2.isEmpty() && note3.isEmpty()) {
            not1 = Double.parseDouble(note1);
            not2 = Double.parseDouble(note2);
            not3 = 21 - (not1 + not2);
            not3Nota = 15 - (not1 + not2);
            this.note3 = "Apv: " + Double.toString(not3)
                    + "| ApvNota: " + Double.toString(not3Nota);

        } else if (!note1.isEmpty() && note2.isEmpty() && note3.isEmpty()) {
            not1 = Double.parseDouble(note1);
            not2 = (21 - not1) / 2;
            not2Nota = (15 - not1) / 2;
            this.note2 = "Apv: " + Double.toString(not2)
                    + "| ApvNota: " + Double.toString(not2Nota);

            this.note3 = "Apv: " + Double.toString(not2)
                    + "| ApvNota: " + Double.toString(not2Nota);



        } else if (note1.isEmpty() && !note2.isEmpty() && note3.isEmpty()) {
            not2 = Double.parseDouble(note2);
            not1 = (21 - not2) / 2;
            not1Nota = (15 - not2) / 2;
            this.note1 = "Apv: " + Double.toString(not1)
                    + "| ApvNota: " + Double.toString(not1Nota);
            this.note3 = "Apv: " + Double.toString(not1)
                    + "| ApvNota: " + Double.toString(not1Nota);


        } else if (note1.isEmpty() && note2.isEmpty() && !note3.isEmpty()) {
            not3 = Double.parseDouble(note3);
            not1 = (21 - not3) / 2;
            not1Nota = (15 - not3) / 2;
            this.note1 = "Apv: " + Double.toString(not1)
                    + "| ApvNota: " + Double.toString(not1Nota);
            this.note2 = "Apv: " + Double.toString(not1)
                    + "| ApvNota: " + Double.toString(not1Nota);
        }


     }



    public String calcularmedia(String not1, String not2, String not3){
        double resultado = 0;
        double notas[]= { Double.parseDouble(not1),
                Double.parseDouble(not2),
                Double.parseDouble(not3)  };

        for(int i = 0; i < notas.length; i++){
            resultado +=  notas[i];

        }
        resultado = resultado / notas.length;

        return String.format("%.2f", resultado);
     }

    public String situacao (double sit){

        String situacaoRes = "";

        if(sit >= 7){
            situacaoRes = "Aprovado";
        }
        else if(sit < 7 && sit >= 5){
            situacaoRes="Aprovado por nota";
        }
        else if( sit < 5){
            situacaoRes = "Reprovado";
        }

        return situacaoRes;
     }

    public boolean isNotNumeric(String str) {
        return !str.matches("-?\\d+(\\.\\d+)?");
    }

}