package com.example.aula10.model;

import java.util.ArrayList;

public class BancoDAO {
    ArrayList<Contato> contatos;
    private static BancoDAO instance;
    public static BancoDAO getInstance(){
        if(instance == null){
            instance = new BancoDAO();
        }return instance;
    }
    private BancoDAO(){
        contatos = new ArrayList<>();
    }

    public void salvarContato(Contato contato){
        contatos.add(contato);
    }

}
